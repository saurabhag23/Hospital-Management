<?php
	include('../header.php');
  include('connection.php');


?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<script type="text/javascript" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#state').DataTable();
} );
</script>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
    <br />         
  <table class="table table-bordered" id="state">
    <thead>
      <tr>
        <th>Codes</th>
        <th>State Name</th>
        
      </tr>
    </thead>
    <tbody>
      <?php
      $select = $connection->query("SELECT * FROM state");
      while($row = $select->fetch_array()){ ?>

      	<tr>
      		<td><?php echo $row['state_code'];?></td>
      		<td><?php echo $row['state_name'];?></td>
      
      	</tr>
      	
      </form>
      
    </div>
  </div>


  



      <?php }
      ?>
    </tbody>
  </table>
</div>


		
				</div>
				</div>

<!-- add state modal -->
<div class="modal fade" id="addstate" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title">Add State</h4>
        </div>
        <div class="modal-body">
        <form action="add_state.php" method="post">
          <div class="form-group">
          	<input type="text" class="form-control" name="code" id="code" placeholder="Enter Code"></input>
          </div>
          <div class="form-group">
          	<input type="text" class="form-control" name="state" id="state" placeholder="Enter State"></input>
          </div>
          <div class="form-group">
          	<textarea type="text" class="form-control" name="description" id="description" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="addstate">Add</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
<?php
	include('../footer.php');
?>