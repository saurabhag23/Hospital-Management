<?php
	include('../header.php');
  include('connection.php');
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<script type="text/javascript" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
    $('#city').DataTable();
} );
</script>
<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">

  
  <table class="table table-bordered" id="city">
    <thead>
      <tr>
        <th>Code</th>
        <th>City Name</th>
        <th>State Name</th>
        
      </tr>
    </thead>
    <tbody>
      <?php
      $city = $connection->query("SELECT state.state_id, state.state_name, city.city_id, city.city_code, city.city_name, city.state_fk FROM city LEFT JOIN state ON state.state_id=city.state_fk");
      while($row=$city->fetch_array()){
       ?>

      	<tr>
        <td><?php echo $row['city_code'];?></td>
        <td><?php echo $row['city_name'];?></td>
      	<td><?php echo $row['state_name'];?></td>
      		

      	</tr>

  <!-- edit state modal -->
 
 
<?php }
      ?>
    </tbody> 
  </table>
</div>
	</div>
</div>

<!-- add state modal -->
<div class="modal fade" id="addcity" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add City</h4>
        </div>
        <div class="modal-body">
        <form action="add_city.php" method="post">
          <div class="form-group">
          	<input type="text" class="form-control" name="code" id="code" placeholder="Enter Code"></input>
          </div>
          <div class="form-group">
            <select class="form-control" name="state" id="state" >
              <option> Select</option>
              <?php
              $state = $connection->query("SELECT * FROM state");
              while($fetch = $state->fetch_array()){?>
               <option value="<?php echo $fetch['state_id']?>"> <?php echo $fetch['state_name']?></option>
              <?php }
              ?>
             
            </select>
          </div>
          <div class="form-group">
            <input type="text" class="form-control" name="city" id="city" placeholder="Enter city"></input>
          </div>
          
          <div class="form-group">
          	<textarea type="text" class="form-control" name="description" id="description" placeholder="Enter Description"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary" name="addcity">Add</button>
        </div>
        </form>
      </div>
      
    </div>
  </div>
<?php
	include('../footer.php');
?>