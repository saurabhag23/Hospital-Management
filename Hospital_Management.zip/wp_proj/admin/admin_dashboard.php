<?php
	include('../header.php');
	
?>
    <style type="text/css">
      ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #00cc7a;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: #008055;
}

.header{
  background-color: #1a651a;
}

.profile_info{
  float: right;
}
body{
	background-color: #ffe6e6;
}

    </style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<!DOCTYPE html>
<html>
<title>W3.CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body class="w3-black">

<div class="w3-display-container">
  <img src="../images/bb1.png"  style="width:100%;height:400px">
  <div class="w3-display-middle w3-large">
  
  </div>

</div>

<div class="w3-container w3-deep-orange w3-large w3-padding-16" style="margin-right:10%">
  <p>3000 <span class="w3-xlarge">DONORS</span>  this month</p>
</div>
<div class="w3-container w3-deep-purple w3-large w3-padding-16" style="margin-left:10%">
  <p>Total 8 <span class="w3-xlarge">BLOOD GROUPS</span>.</p>
</div>



</body>
</html>
