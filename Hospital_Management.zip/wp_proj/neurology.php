<?php
include('navbar.php')
?>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

   <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>
    <center>
 <strong style="font-size: 40px">Neurology</strong>
</center>
  <main role="main">

  
  <div class="album py-5 bg-light">
    <div class="container">

      <div class="row">
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="images/d7.jpg">
            <div class="card-body">
              <p class="card-text"><center><b>Dr.Richa Parte</b></center><br><i>"The best doctor gives the least medicines."</i></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">

                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="images/d2.jpg">
            <div class="card-body">
              <p class="card-text"><center><b>Dr.Paresh Singhal</b></center><br><i>"The best doctor gives the least medicines."</i></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">

                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="images/d8.jpg">
            <div class="card-body">
              <p class="card-text"><center><b>Dr.Manjitdada Patil</b></center><br><i>"The best doctor gives the least medicines."</i></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">

                </div>

              </div>
            </div>
          </div>
        </div>

        <div class="col-md-4">
          <div class="card mb-4 shadow-sm">
            <img src="images/d4.jpg">
            <div class="card-body">
              <p class="card-text"><center><b>Dr.Udit Dayani</b></center><br><i>"The best doctor gives the least medicines."</i></p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">

                </div>
  
              </div>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  </div>

</main>

  
